package com.example.senceparking

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.rememberNavController
import com.example.senceparking.core.GoogleAuthUiClient
import com.example.senceparking.ui.login.LoginScreen
import com.example.senceparking.ui.theme.SenceParkingTheme
import kotlinx.coroutines.launch

class LoginActivity : ComponentActivity() {
    private lateinit var googleAuthUiClient: GoogleAuthUiClient

    // ✅ Google 로그인 결과를 처리할 ActivityResultLauncher
    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            Log.d("LoginActivity", "Google 로그인 성공")
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            Log.e("LoginActivity", "Google 로그인 실패")
            Toast.makeText(this, "로그인 실패", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            googleAuthUiClient = GoogleAuthUiClient(this)

            if (googleAuthUiClient.isUserLoggedIn()) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
                return
            }

            setContent {
                val navController = rememberNavController() // ✅ NavController 생성
                val googleAuthUiClient = GoogleAuthUiClient(this) // ✅ GoogleAuthUiClient 생성

                SenceParkingTheme {
                    LoginScreen(navController, googleAuthUiClient, onGoogleSignInClick = {
                        try {
                            val signInIntent = googleAuthUiClient.getSignInIntent()
                            signInLauncher.launch(signInIntent)
                        } catch (e: Exception) {
                            Log.e("LoginActivity", "Google 로그인 오류", e)
                            Toast.makeText(this@LoginActivity, "로그인 실패", Toast.LENGTH_SHORT).show()
                        }
                    })
                }
            }
        } catch (e: Exception) {
            Log.e("LoginActivity", "GoogleAuthUiClient 초기화 오류", e)
            Toast.makeText(this, "로그인 시스템 오류", Toast.LENGTH_SHORT).show()
        }
    }
}